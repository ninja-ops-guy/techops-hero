"""Counterbalanced first-attempts on the exact candidate, separate contexts and no retries."""
import datetime
import hashlib
import atexit
import http.client
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import platform

root = Path(__file__).resolve().parent
out = root/'receipt'/'night-webkit'
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()
def run(command, **kwargs):
    return subprocess.check_output(command, text=True, **kwargs).strip()
workload = """print('ready', flush=True)
x=1
while True: x=(1664525*x+1013904223)&0xffffffff
"""
# Server and browsers must be descendants of the same sandbox invocation.
# Verify candidate bytes before starting or counting a study trial.
server_log = (out/'server.log').open('wb')
server = subprocess.Popen(['taskset','-c','4',sys.executable,'scripts/media_http_server.py',
                           '--port','47139','--bind','127.0.0.1'],cwd=root/'source',
                          stdout=server_log,stderr=subprocess.STDOUT)
def stop_server():
    server.terminate()
    server.wait(timeout=5)
    server_log.close()
atexit.register(stop_server)
candidate_index_sha = sha(root/'source/index.html')
for poll in range(30):
    if server.poll() is not None: raise RuntimeError('media server terminated before preflight')
    connection = http.client.HTTPConnection('127.0.0.1',47139,timeout=2)
    try:
        connection.request('GET','/index.html')
        response=connection.getresponse()
        if response.status!=200 or hashlib.sha256(response.read()).hexdigest()!=candidate_index_sha:
            raise RuntimeError('served candidate mismatch')
        break
    except ConnectionRefusedError:
        time.sleep(0.1)
    finally:
        connection.close()
else: raise RuntimeError('server never accepted connections')
pairs = 10
trial_plan = []
for pair in range(1,pairs+1):
    for condition in (['baseline','contention'] if pair%2 else ['contention','baseline']):
        trial_plan.append({'pair':pair,'condition':condition})
plan = {'source':json.loads((root/'receipt/release-asset-manifest.json').read_text())['source'],
        'started_utc':utc(),'trials':trial_plan,'loopback_preflight_index_sha256':candidate_index_sha,'game':'loopback copy of verified merge, isolated fresh Linux WebKit 26.0 emulated iPhone 13 context per trial, real protocol touch navigation and keyboard combat',
        'cpu_affinity':[2,3],'contention':'one competing CPU loop pinned to each of CPU 2 and 3; only the probe process and its descendants use this same two-CPU affinity; HTTP server pinned to CPU 4',
        'workers_code':workload,'trial_limit_s':180,'browser_timeout_ms':15000,'window_ms':340,
        'stop_rule':'stop after two consecutive identical pre-dash setup failures and keep all initiated records; gameplay failures do not stop the study',
        'capture':'stock browser tracing, passive trusted key listener ahead of the game, snapshot after original fromDash assertion and screenshot or upon failure',
        'margin':'combat-clock deadline minus combat time at trusted KeyE keydown; separately confirmed by fromDash event time',
        'host':platform.platform(),'node':run(['node','--version']),
        'playwright':run(['node','-p',"require('playwright/package.json').version"],cwd=root/'source')}
(out/'plan.json').open('x').write(json.dumps(plan,indent=2)+'\n')
previous_setup_error = None
for ordinal, trial in enumerate(trial_plan,1):
    path = out / f'{ordinal:02}-{trial["condition"]}'
    path.mkdir(exist_ok=False)
    print('Starting',path.name,utc(),flush=True)
    workers = []
    stat = {'ordinal':ordinal,**trial,'started_utc':utc(),'worker_cpu_seconds':[]}
    try:
        if trial['condition']=='contention':
            for cpu in plan['cpu_affinity']:
                p=subprocess.Popen(['taskset','-c',str(cpu),sys.executable,'-u','-c',workload],
                                   stdout=subprocess.PIPE,text=True)
                workers.append(p)
                if p.stdout.readline().strip()!='ready': raise RuntimeError('load worker failed to start')
                if os.sched_getaffinity(p.pid)!={cpu}: raise RuntimeError('load worker affinity mismatch')
        t=time.monotonic()
        with (path/'process.log').open('w') as log:
            proc=subprocess.Popen(['taskset','-c','2,3','node',str(root/'rig/scripts/night_dash_probe_webkit.mjs')],
                     cwd=root/'source', start_new_session=True,stdout=log,stderr=subprocess.STDOUT,
                     env={**os.environ,'NIGHT_COMBAT_BROWSERS':'webkit',
                          'BOT_OUT_DIR':str(path),'BOT_BASE_URL':'http://127.0.0.1:47139/'})
            try: stat['process_exit']=proc.wait(timeout=180)
            except subprocess.TimeoutExpired:
                stat['timeout_s']=180
                os.killpg(proc.pid,signal.SIGTERM)
                try: proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGKILL)
                    proc.wait()
                stat['process_exit']=proc.returncode
        stat['elapsed_s']=round(time.monotonic()-t,3)
        for p in workers:
            stat_fields=Path('/proc',str(p.pid),'stat').read_text().split()
            stat['worker_cpu_seconds'].append((int(stat_fields[13])+int(stat_fields[14]))/os.sysconf('SC_CLK_TCK'))
    finally:
        for p in workers:
            p.terminate()
            p.wait()
    stat['finished_utc']=utc()
    rec = json.loads((path/'night-combat.json').read_text())[0] if (path/'night-combat.json').is_file() else {}
    times = rec.get('dashTiming') or {}
    downs = [k for k in times.get('keys',[]) if k['kind']=='keydown']
    punch = next((k for k in downs if k['code']=='KeyE' and k['trusted']),{})
    grab = next((e for e in times.get('events',[]) if e['type']=='grab' and e.get('fromDash')), {})
    def delta(a,b):
        return round(a-b,4) if isinstance(a,(int,float)) and isinstance(b,(int,float)) else None
    second_tap = next(iter([k for k in downs if k['code']=='ArrowRight'][1:]),{})
    stat.update(passed=stat['process_exit']==0 and rec.get('pass') is True,
                error=rec.get('error'),browser_version=rec.get('browserVersion'),
                punch_margin_ms=delta(punch.get('dashDeadlineMs'),punch.get('simMs')),
                grab_margin_ms=delta(punch.get('dashDeadlineMs'),grab.get('time')),
                second_tap_to_punch_wall_ms=delta(punch.get('wallMs'),second_tap.get('wallMs')),
                timing=times,artifacts={p.name:sha(p) for p in sorted(path.iterdir()) if p.is_file()})
    (path/'trial.json').write_text(json.dumps(stat,indent=2)+'\n')
    print('Result',ordinal,trial['condition'],stat['passed'],stat['punch_margin_ms'],stat['error'],flush=True)

    setup_error = (stat['error'] or f"exit {stat['process_exit']}").splitlines()[0] if not stat['passed'] and not times.get('armed') else None
    if setup_error and setup_error == previous_setup_error:
        print('Study stopped at preregistered repeated setup error:',setup_error,flush=True)
        break
    previous_setup_error = setup_error
