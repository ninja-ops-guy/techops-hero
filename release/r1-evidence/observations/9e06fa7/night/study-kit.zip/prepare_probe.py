"""Build an external, focused observer from this particular source version's real Night bot."""
from pathlib import Path
import hashlib
import shutil
import sys
source, rig = (Path(arg).resolve() for arg in sys.argv[1:3])
path = source / 'scripts' / 'night_combat_bot.mjs'
original = path.read_bytes()
bot = original.decode()
rig_scripts = rig / 'scripts'
rig_scripts.mkdir(parents=True, exist_ok=True)
(rig/'node_modules').symlink_to(source/'node_modules',target_is_directory=True)
for name in ['night_combat_diagnostics.mjs','runtime_evidence_capture.mjs','room_bootstrap_snapshot.mjs']:
    shutil.copyfile(source/'scripts'/name,rig_scripts/name)
def once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old,new)
start = '  await setup(770);'
end = "  for(const direction of ['left','right','up','down'])"
segment = bot[bot.index(start):bot.index(end)]
prefix = bot[:bot.index(start)]
observer = """
  await context.addInitScript(() => {
   if (window.top !== window) return;
   const keys = [];
   window.__r1DashEvidenceKeys = keys;
   for (const kind of ['keydown', 'keyup']) {
    window.addEventListener(kind, event => {
     if (!['ArrowRight', 'KeyE'].includes(event.code) || !window.__r1DashMeasuring) return;
     const combat = typeof NM !== 'undefined' && NM && NM._nightCombat;
     if (keys.length < 16) keys.push({
      kind, code:event.code, trusted:event.isTrusted,
      wallMs:performance.now(), eventMs:event.timeStamp, simMs:combat?.time ?? null,
      dashStartMs:combat?.dash?.at ?? null, dashDeadlineMs:combat?.dash?.until ?? null
     });
    }, {capture:true, passive:true});
   }
  });
"""
# Install observation before the game, and arm it before the original fixture is set up.
prefix = once(prefix, '  capture=await',observer+'  capture=await')
prefix += '  await page.evaluate(() => { window.__r1DashMeasuring = true; });\n'
readout = """
async function readEvidence(page) {
 return page.evaluate(() => {
  const combat = typeof NM !== 'undefined' && NM && NM._nightCombat;
  return {armed:window.__r1DashMeasuring === true, ruleMs:window.TechOpsNightCombat?.RULES.dashGrabWindow ?? null,
   keys:window.__r1DashEvidenceKeys ?? [], dash:combat?.dash ?? null,
   events:(combat?.events ?? []).map(({id,type,time,fromDash,kind})=>({id,type,time,fromDash,kind}))};
 });
}
"""
tail = bot[bot.index('  if(errors.length)throw Error'):];
tail = once(tail,'}catch(e){profileError=e;',""" }catch(e){
  if(page) record.dashTiming = await readEvidence(page).catch(() => null);
  profileError=e;""")
capture = """
  record.dashTiming = await readEvidence(page);
  const timing = record.dashTiming;
  const downs = timing.keys.filter(event => event.kind === 'keydown');
  const grab = timing.events.find(event => event.type === 'grab' && event.fromDash === true);
  const punch = downs.find(event => event.code === 'KeyE');
  if (!timing.armed || timing.ruleMs !== 340 || downs.map(x=>x.code).join(',') !== 'ArrowRight,ArrowRight,KeyE' ||
      !downs.every(x=>x.trusted) || !Number.isFinite(punch?.dashStartMs) || !Number.isFinite(punch?.dashDeadlineMs) ||
      punch.dashDeadlineMs - punch.dashStartMs !== 340 || !Number.isFinite(grab?.time) ||
      !Number.isFinite(punch.simMs) || punch.dashStartMs > punch.simMs || punch.simMs > punch.dashDeadlineMs ||
      grab.time < punch.simMs || grab.time > punch.dashDeadlineMs) {
   throw Error('Timed sequence lacks trusted input, an in-window grab or valid 340 ms clock evidence');
  }
"""
result = (prefix+segment+capture+tail+'\n'+readout).encode()
assert result.count(segment.encode()) == 1
(rig_scripts/'night_dash_probe.mjs').write_bytes(result)
print('Source bot SHA-256',hashlib.sha256(original).hexdigest())
print('Unchanged fixture/input/assertion segment SHA-256',hashlib.sha256(segment.encode()).hexdigest())
print('Focused probe SHA-256',hashlib.sha256(result).hexdigest())
